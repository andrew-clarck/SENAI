import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=6dc2f12a";
import Produtos from "/src/pages/Produtos.jsx";
import Clientes from "/src/pages/Clientes.jsx";
import Pedidos from "/src/pages/Pedidos.jsx";
var _jsxFileName = "C:/Users/51453200860/Documents/SENAI/SENAI/Testes de Software/Aulas/aula07_testes_end_2_end/web/src/App.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6dc2f12a";
var _s = $RefreshSig$();
const ABAS = {
	Produtos,
	Clientes,
	Pedidos
};
export default function App() {
	_s();
	const [aba, setAba] = useState("Produtos");
	const Pagina = ABAS[aba];
	return /* @__PURE__ */ _jsxDEV("main", { children: [
		/* @__PURE__ */ _jsxDEV("h1", { children: "Lanchonete" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 14,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("nav", { children: Object.keys(ABAS).map((nome) => /* @__PURE__ */ _jsxDEV("button", {
			disabled: nome === aba,
			onClick: () => setAba(nome),
			children: nome
		}, nome, false, {
			fileName: _jsxFileName,
			lineNumber: 17,
			columnNumber: 11
		}, this)) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 15,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Pagina, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 22,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 13,
		columnNumber: 5
	}, this);
}
_s(App, "SQGK43ysBiN1X9n/sLhLyuuWoXQ=");
_c = App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/51453200860/Documents/SENAI/SENAI/Testes de Software/Aulas/aula07_testes_end_2_end/web/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/51453200860/Documents/SENAI/SENAI/Testes de Software/Aulas/aula07_testes_end_2_end/web/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/51453200860/Documents/SENAI/SENAI/Testes de Software/Aulas/aula07_testes_end_2_end/web/src/App.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsT0FBTyxjQUFjO0FBQ3JCLE9BQU8sY0FBYztBQUNyQixPQUFPLGFBQWE7Ozs7QUFFcEIsTUFBTSxPQUFPO0NBQUU7Q0FBVTtDQUFVO0FBQVE7QUFFM0MsZUFBZSxTQUFTLE1BQU07O0NBQzVCLE1BQU0sQ0FBQyxLQUFLLFVBQVUsU0FBUyxVQUFVO0NBQ3pDLE1BQU0sU0FBUyxLQUFLO0NBRXBCLE9BQ0Usd0JBQUMsUUFBRDtFQUNFLHdCQUFDLE1BQUQsWUFBSSxhQUFjOzs7OztFQUNsQix3QkFBQyxPQUFELFlBQ0csT0FBTyxLQUFLLElBQUksQ0FBQyxDQUFDLEtBQUssU0FDdEIsd0JBQUMsVUFBRDtHQUFtQixVQUFVLFNBQVM7R0FBSyxlQUFlLE9BQU8sSUFBSTthQUNsRTtFQUNLLEdBRks7Ozs7U0FFTCxDQUNULEVBQ0U7Ozs7O0VBQ0wsd0JBQUMsUUFBRCxDQUFTOzs7OztDQUNMOzs7OztBQUVWIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFwcC5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCBQcm9kdXRvcyBmcm9tICcuL3BhZ2VzL1Byb2R1dG9zLmpzeCc7XHJcbmltcG9ydCBDbGllbnRlcyBmcm9tICcuL3BhZ2VzL0NsaWVudGVzLmpzeCc7XHJcbmltcG9ydCBQZWRpZG9zIGZyb20gJy4vcGFnZXMvUGVkaWRvcy5qc3gnO1xyXG5cclxuY29uc3QgQUJBUyA9IHsgUHJvZHV0b3MsIENsaWVudGVzLCBQZWRpZG9zIH07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBcHAoKSB7XHJcbiAgY29uc3QgW2FiYSwgc2V0QWJhXSA9IHVzZVN0YXRlKCdQcm9kdXRvcycpO1xyXG4gIGNvbnN0IFBhZ2luYSA9IEFCQVNbYWJhXTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxtYWluPlxyXG4gICAgICA8aDE+TGFuY2hvbmV0ZTwvaDE+XHJcbiAgICAgIDxuYXY+XHJcbiAgICAgICAge09iamVjdC5rZXlzKEFCQVMpLm1hcCgobm9tZSkgPT4gKFxyXG4gICAgICAgICAgPGJ1dHRvbiBrZXk9e25vbWV9IGRpc2FibGVkPXtub21lID09PSBhYmF9IG9uQ2xpY2s9eygpID0+IHNldEFiYShub21lKX0+XHJcbiAgICAgICAgICAgIHtub21lfVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgKSl9XHJcbiAgICAgIDwvbmF2PlxyXG4gICAgICA8UGFnaW5hIC8+XHJcbiAgICA8L21haW4+XHJcbiAgKTtcclxufVxyXG4iXX0=