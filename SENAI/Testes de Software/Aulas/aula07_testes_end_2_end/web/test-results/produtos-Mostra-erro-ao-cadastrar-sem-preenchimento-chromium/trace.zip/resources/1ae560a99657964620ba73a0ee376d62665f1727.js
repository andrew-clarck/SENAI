import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Produtos.jsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=6dc2f12a";
import { api, moeda } from "/src/api.js";
var _jsxFileName = "C:/Users/51453200860/Documents/SENAI/SENAI/Testes de Software/Aulas/aula07_testes_end_2_end/web/src/pages/Produtos.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6dc2f12a";
var _s = $RefreshSig$();
export default function Produtos() {
	_s();
	const [produtos, setProdutos] = useState([]);
	const [nome, setNome] = useState("");
	const [preco, setPreco] = useState("");
	const [erro, setErro] = useState("");
	const carregar = () => api("/produtos").then(setProdutos);
	useEffect(() => {
		carregar();
	}, []);
	async function cadastrar(e) {
		e.preventDefault();
		try {
			await api("/produtos", "POST", {
				nome,
				preco: Number(preco)
			});
			setNome("");
			setPreco("");
			setErro("");
			carregar();
		} catch (err) {
			setErro(err.message);
		}
	}
	async function remover(id) {
		await api(`/produtos/${id}`, "DELETE");
		carregar();
	}
	return /* @__PURE__ */ _jsxDEV("section", { children: [
		/* @__PURE__ */ _jsxDEV("h2", { children: "Produtos" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 36,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("form", {
			onSubmit: cadastrar,
			children: [
				/* @__PURE__ */ _jsxDEV("input", {
					"aria-label": "Nome",
					placeholder: "Nome",
					value: nome,
					onChange: (e) => setNome(e.target.value)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 38,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("input", {
					"aria-label": "Preco",
					placeholder: "Preco",
					type: "number",
					step: "0.01",
					value: preco,
					onChange: (e) => setPreco(e.target.value)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 39,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					type: "submit",
					children: "Cadastrar"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 40,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 37,
			columnNumber: 7
		}, this),
		erro && /* @__PURE__ */ _jsxDEV("p", {
			className: "erro",
			children: erro
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 42,
			columnNumber: 16
		}, this),
		/* @__PURE__ */ _jsxDEV("table", { children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", { children: [
			/* @__PURE__ */ _jsxDEV("th", { children: "Nome" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 46,
				columnNumber: 15
			}, this),
			/* @__PURE__ */ _jsxDEV("th", { children: "Preco" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 46,
				columnNumber: 28
			}, this),
			/* @__PURE__ */ _jsxDEV("th", {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 46,
				columnNumber: 42
			}, this)
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 46,
			columnNumber: 11
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 45,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: produtos.map((p) => /* @__PURE__ */ _jsxDEV("tr", { children: [
			/* @__PURE__ */ _jsxDEV("td", { children: p.nome }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 51,
				columnNumber: 15
			}, this),
			/* @__PURE__ */ _jsxDEV("td", { children: moeda(p.preco) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 52,
				columnNumber: 15
			}, this),
			/* @__PURE__ */ _jsxDEV("td", { children: /* @__PURE__ */ _jsxDEV("button", {
				onClick: () => remover(p.id),
				children: "Remover"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 53,
				columnNumber: 19
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 53,
				columnNumber: 15
			}, this)
		] }, p.id, true, {
			fileName: _jsxFileName,
			lineNumber: 50,
			columnNumber: 13
		}, this)) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 48,
			columnNumber: 9
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 44,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 35,
		columnNumber: 5
	}, this);
}
_s(Produtos, "l2dm0UthKsgNYSv07zHgc7XI53g=");
_c = Produtos;
var _c;
$RefreshReg$(_c, "Produtos");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Produtos.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/51453200860/Documents/SENAI/SENAI/Testes de Software/Aulas/aula07_testes_end_2_end/web/src/pages/Produtos.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/51453200860/Documents/SENAI/SENAI/Testes de Software/Aulas/aula07_testes_end_2_end/web/src/pages/Produtos.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/51453200860/Documents/SENAI/SENAI/Testes de Software/Aulas/aula07_testes_end_2_end/web/src/pages/Produtos.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLEtBQUssYUFBYTs7OztBQUUzQixlQUFlLFNBQVMsV0FBVzs7Q0FDakMsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLENBQUMsQ0FBQztDQUMzQyxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVMsRUFBRTtDQUNuQyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVMsRUFBRTtDQUVuQyxNQUFNLGlCQUFpQixJQUFJLFdBQVcsQ0FBQyxDQUFDLEtBQUssV0FBVztDQUV4RCxnQkFBZ0I7RUFDZCxTQUFTO0NBQ1gsR0FBRyxDQUFDLENBQUM7Q0FFTCxlQUFlLFVBQVUsR0FBRztFQUMxQixFQUFFLGVBQWU7RUFDakIsSUFBSTtHQUNGLE1BQU0sSUFBSSxhQUFhLFFBQVE7SUFBRTtJQUFNLE9BQU8sT0FBTyxLQUFLO0dBQUUsQ0FBQztHQUM3RCxRQUFRLEVBQUU7R0FDVixTQUFTLEVBQUU7R0FDWCxRQUFRLEVBQUU7R0FDVixTQUFTO0VBQ1gsU0FBUyxLQUFLO0dBQ1osUUFBUSxJQUFJLE9BQU87RUFDckI7Q0FDRjtDQUVBLGVBQWUsUUFBUSxJQUFJO0VBQ3pCLE1BQU0sSUFBSSxhQUFhLE1BQU0sUUFBUTtFQUNyQyxTQUFTO0NBQ1g7Q0FFQSxPQUNFLHdCQUFDLFdBQUQ7RUFDRSx3QkFBQyxNQUFELFlBQUksV0FBWTs7Ozs7RUFDaEIsd0JBQUMsUUFBRDtHQUFNLFVBQVU7YUFBaEI7SUFDRSx3QkFBQyxTQUFEO0tBQU8sY0FBVztLQUFPLGFBQVk7S0FBTyxPQUFPO0tBQU0sV0FBVyxNQUFNLFFBQVEsRUFBRSxPQUFPLEtBQUs7SUFBSTs7Ozs7SUFDcEcsd0JBQUMsU0FBRDtLQUFPLGNBQVc7S0FBUSxhQUFZO0tBQVEsTUFBSztLQUFTLE1BQUs7S0FBTyxPQUFPO0tBQU8sV0FBVyxNQUFNLFNBQVMsRUFBRSxPQUFPLEtBQUs7SUFBSTs7Ozs7SUFDbEksd0JBQUMsVUFBRDtLQUFRLE1BQUs7ZUFBUztJQUFpQjs7Ozs7R0FDbkM7Ozs7OztFQUNMLFFBQVEsd0JBQUMsS0FBRDtHQUFHLFdBQVU7YUFBUTtFQUFROzs7OztFQUV0Qyx3QkFBQyxTQUFELGFBQ0Usd0JBQUMsU0FBRCxZQUNFLHdCQUFDLE1BQUQ7R0FBSSx3QkFBQyxNQUFELFlBQUksT0FBUTs7Ozs7R0FBQyx3QkFBQyxNQUFELFlBQUksUUFBUzs7Ozs7R0FBQyx3QkFBQyxNQUFELENBQVE7Ozs7O0VBQUs7Ozs7V0FDdkM7Ozs7WUFDUCx3QkFBQyxTQUFELFlBQ0csU0FBUyxLQUFLLE1BQ2Isd0JBQUMsTUFBRDtHQUNFLHdCQUFDLE1BQUQsWUFBSyxFQUFFLEtBQVM7Ozs7O0dBQ2hCLHdCQUFDLE1BQUQsWUFBSyxNQUFNLEVBQUUsS0FBSyxFQUFNOzs7OztHQUN4Qix3QkFBQyxNQUFELFlBQUksd0JBQUMsVUFBRDtJQUFRLGVBQWUsUUFBUSxFQUFFLEVBQUU7Y0FBRztHQUFlOzs7O1lBQUs7Ozs7O0VBQzVELEtBSkssRUFBRTs7OztTQUlQLENBQ0wsRUFDSTs7OztVQUNGOzs7OztDQUNBOzs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlByb2R1dG9zLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBhcGksIG1vZWRhIH0gZnJvbSAnLi4vYXBpLmpzJztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFByb2R1dG9zKCkge1xyXG4gIGNvbnN0IFtwcm9kdXRvcywgc2V0UHJvZHV0b3NdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtub21lLCBzZXROb21lXSA9IHVzZVN0YXRlKCcnKTtcclxuICBjb25zdCBbcHJlY28sIHNldFByZWNvXSA9IHVzZVN0YXRlKCcnKTtcclxuICBjb25zdCBbZXJybywgc2V0RXJyb10gPSB1c2VTdGF0ZSgnJyk7XHJcblxyXG4gIGNvbnN0IGNhcnJlZ2FyID0gKCkgPT4gYXBpKCcvcHJvZHV0b3MnKS50aGVuKHNldFByb2R1dG9zKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNhcnJlZ2FyKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBhc3luYyBmdW5jdGlvbiBjYWRhc3RyYXIoZSkge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgYXBpKCcvcHJvZHV0b3MnLCAnUE9TVCcsIHsgbm9tZSwgcHJlY286IE51bWJlcihwcmVjbykgfSk7XHJcbiAgICAgIHNldE5vbWUoJycpO1xyXG4gICAgICBzZXRQcmVjbygnJyk7XHJcbiAgICAgIHNldEVycm8oJycpO1xyXG4gICAgICBjYXJyZWdhcigpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIHNldEVycm8oZXJyLm1lc3NhZ2UpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gcmVtb3ZlcihpZCkge1xyXG4gICAgYXdhaXQgYXBpKGAvcHJvZHV0b3MvJHtpZH1gLCAnREVMRVRFJyk7XHJcbiAgICBjYXJyZWdhcigpO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxzZWN0aW9uPlxyXG4gICAgICA8aDI+UHJvZHV0b3M8L2gyPlxyXG4gICAgICA8Zm9ybSBvblN1Ym1pdD17Y2FkYXN0cmFyfT5cclxuICAgICAgICA8aW5wdXQgYXJpYS1sYWJlbD1cIk5vbWVcIiBwbGFjZWhvbGRlcj1cIk5vbWVcIiB2YWx1ZT17bm9tZX0gb25DaGFuZ2U9eyhlKSA9PiBzZXROb21lKGUudGFyZ2V0LnZhbHVlKX0gLz5cclxuICAgICAgICA8aW5wdXQgYXJpYS1sYWJlbD1cIlByZWNvXCIgcGxhY2Vob2xkZXI9XCJQcmVjb1wiIHR5cGU9XCJudW1iZXJcIiBzdGVwPVwiMC4wMVwiIHZhbHVlPXtwcmVjb30gb25DaGFuZ2U9eyhlKSA9PiBzZXRQcmVjbyhlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCI+Q2FkYXN0cmFyPC9idXR0b24+XHJcbiAgICAgIDwvZm9ybT5cclxuICAgICAge2Vycm8gJiYgPHAgY2xhc3NOYW1lPVwiZXJyb1wiPntlcnJvfTwvcD59XHJcblxyXG4gICAgICA8dGFibGU+XHJcbiAgICAgICAgPHRoZWFkPlxyXG4gICAgICAgICAgPHRyPjx0aD5Ob21lPC90aD48dGg+UHJlY288L3RoPjx0aD48L3RoPjwvdHI+XHJcbiAgICAgICAgPC90aGVhZD5cclxuICAgICAgICA8dGJvZHk+XHJcbiAgICAgICAgICB7cHJvZHV0b3MubWFwKChwKSA9PiAoXHJcbiAgICAgICAgICAgIDx0ciBrZXk9e3AuaWR9PlxyXG4gICAgICAgICAgICAgIDx0ZD57cC5ub21lfTwvdGQ+XHJcbiAgICAgICAgICAgICAgPHRkPnttb2VkYShwLnByZWNvKX08L3RkPlxyXG4gICAgICAgICAgICAgIDx0ZD48YnV0dG9uIG9uQ2xpY2s9eygpID0+IHJlbW92ZXIocC5pZCl9PlJlbW92ZXI8L2J1dHRvbj48L3RkPlxyXG4gICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC90Ym9keT5cclxuICAgICAgPC90YWJsZT5cclxuICAgIDwvc2VjdGlvbj5cclxuICApO1xyXG59XHJcbiJdfQ==